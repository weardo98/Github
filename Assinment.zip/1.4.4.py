import PIL
import matplotlib.pyplot as plt
import os.path

directory = os.path.dirname(os.path.abspath(__file__))  
student_file = os.path.join(directory, 'student.jpg')
student_img = PIL.Image.open(student_file)
earth_file = os.path.join(directory, 'earth.png')
earth_img = PIL.Image.open(earth_file)
earth_small = earth_img.resize((89, 87))

student_img.paste(earth_small, (1162, 966), mask=earth_small) 
student_img.paste(earth_small, (710, 940), mask=earth_small) 

fig3, axes3 = plt.subplots(1, 2)
axes3[0].imshow(student_img, interpolation='none')
axes3[1].imshow(student_img, interpolation='none')
axes3[1].set_xlim(500, 1500)
axes3[1].set_ylim(1130, 850)
fig3.show()