import matplotlib.pyplot as plt 
import numpy as np

img = plt.imread('woman.jpg')


fig, ax = plt.subplots()
ax.imshow(img, interpolation='none')
fig.show()