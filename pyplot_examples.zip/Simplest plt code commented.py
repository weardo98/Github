# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt 
import numpy as np

#Load the image data
img = plt.imread('woman.jpg')


'''Show the image data'''
# Create figure with 1 subplot
fig, ax = plt.subplots(1, 1)
# Show the image data in a subplot
#ax.imshow(img, interpolation='none')
# Show the figure on the screen
fig.show()